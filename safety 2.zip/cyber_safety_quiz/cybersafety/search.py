"""Keyword / category based record filtering."""
from __future__ import annotations


def search(results, keyword=None, category=None, level=None, min_pct=None, max_pct=None):
    out = []
    kw = keyword.lower() if keyword else None
    for r in results:
        if kw and not any(kw in str(r[f]).lower() for f in ("name", "category", "level", "timestamp")):
            continue
        if category and r["category"] != category:
            continue
        if level and r["level"].lower() != level.lower():
            continue
        if min_pct is not None and r["percent"] < min_pct:
            continue
        if max_pct is not None and r["percent"] > max_pct:
            continue
        out.append(r)
    return out
