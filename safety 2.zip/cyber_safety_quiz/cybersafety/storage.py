"""JSON persistence with corruption recovery and atomic writes."""
from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path

from .models import build_result

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
EXPORT_DIR = ROOT / "exports"
RESULTS_FILE = DATA_DIR / "results.json"
QUESTIONS_FILE = DATA_DIR / "questions.json"
SAMPLE_JSON = DATA_DIR / "sample_results.json"


def load_questions(path: Path = QUESTIONS_FILE) -> list:
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Question bank unavailable ({exc}). Restore data/questions.json.")
    good = []
    for q in data:
        if (isinstance(q, dict) and {"id", "category", "question", "options", "answer", "explanation"} <= q.keys()
                and isinstance(q["options"], list) and len(q["options"]) >= 2
                and isinstance(q["answer"], int) and 0 <= q["answer"] < len(q["options"])):
            good.append(q)
    return good


def load_results(path: Path = RESULTS_FILE) -> list:
    """Return a list of result dicts. Missing/corrupt files are replaced by a clean template."""
    path = Path(path)
    try:
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
        if not isinstance(raw, list):
            raise json.JSONDecodeError("root must be a list", "", 0)
    except FileNotFoundError:
        save_results([], path)
        return []
    except json.JSONDecodeError:
        backup = path.with_suffix(f".corrupt-{datetime.now():%Y%m%d%H%M%S}.json")
        shutil.copy2(path, backup)
        print(f"  ! Results file was corrupted; backup saved as {backup.name}. Starting fresh.")
        save_results([], path)
        return []
    clean = []
    for row in raw:  # schema check, skip bad rows
        try:
            clean.append(build_result(row["id"], row["name"], row["category"], row["total"],
                                      row["correct"], row["duration_sec"], row.get("timestamp")).to_dict())
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
    return clean


def save_results(results: list, path: Path = RESULTS_FILE) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    os.replace(tmp, path)


def next_id(results: list) -> int:
    return max((r["id"] for r in results), default=0) + 1
