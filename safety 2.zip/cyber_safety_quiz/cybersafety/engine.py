"""Core logic: quiz selection/grading, password analysis, phishing scan."""
from __future__ import annotations

import random
import re

COMMON_PASSWORDS = {
    "password", "123456", "12345678", "qwerty", "abc123", "letmein", "admin", "welcome",
    "iloveyou", "monkey", "dragon", "football", "111111", "123123", "passw0rd",
}


def select_questions(questions, category, count, rng=None):
    rng = rng or random.Random()
    pool = [q for q in questions if category == "mixed" or q["category"] == category]
    rng.shuffle(pool)
    return pool[:count]


def shuffle_options(q: dict, rng=None) -> dict:
    """Return a copy of the question with options shuffled and the answer index remapped."""
    rng = rng or random.Random()
    order = list(range(len(q["options"])))
    rng.shuffle(order)
    out = dict(q)
    out["options"] = [q["options"][i] for i in order]
    out["answer"] = order.index(q["answer"])
    return out


def grade(answers_correct: list) -> int:
    return sum(1 for ok in answers_correct if ok)


# ---------- password strength ----------
def password_strength(pw: str):
    """Return (score 0-100, label, feedback list)."""
    feedback = []
    if not pw:
        return 0, "Very Weak", ["Password is empty."]
    score = min(len(pw), 20) * 3  # up to 60
    classes = sum(bool(re.search(p, pw)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    score += classes * 10  # up to 40
    if len(pw) < 12:
        feedback.append("Use at least 12 characters (a passphrase of 4+ random words works well).")
    if classes < 3:
        feedback.append("Mix upper/lower case letters, digits and symbols.")
    if pw.lower() in COMMON_PASSWORDS or re.sub(r"\d+$", "", pw.lower()) in COMMON_PASSWORDS:
        score = min(score, 10)
        feedback.append("This is a very common password - attackers try it first.")
    if re.search(r"(.)\1{2,}", pw):
        score -= 15
        feedback.append("Avoid repeated characters (e.g. 'aaa').")
    if re.search(r"(?i)(0123|1234|2345|3456|4567|5678|6789|abcd|bcde|qwer|asdf|zxcv)", pw):
        score -= 15
        feedback.append("Avoid keyboard or sequential patterns.")
    score = max(0, min(100, score))
    label = ("Very Weak", "Weak", "Fair", "Strong", "Very Strong")[min(score // 20, 4)]
    if not feedback:
        feedback.append("Looks good! Also use a unique password per site and enable 2FA.")
    return score, label, feedback


# ---------- phishing scanner ----------
URGENCY = ("urgent", "immediately", "act now", "suspended", "verify your account", "within 24 hours",
           "final notice", "locked", "unusual activity", "confirm your identity")
SENSITIVE = ("password", "otp", "pin", "ssn", "card number", "cvv", "bank details", "login")
SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy")
BAD_TLDS = (".xyz", ".top", ".click", ".gq", ".tk", ".zip", ".work")


def phishing_scan(text: str):
    """Heuristic scan. Returns (risk 0-100, level, flags)."""
    flags, risk = [], 0
    low = text.lower()
    hits = [w for w in URGENCY if w in low]
    if hits:
        risk += min(30, 15 * len(hits))
        flags.append(f"Urgent / threatening language: {', '.join(hits)}")
    hits = [w for w in SENSITIVE if re.search(rf"\b{re.escape(w)}\b", low)]
    if hits:
        risk += min(25, 12 * len(hits))
        flags.append(f"Asks for sensitive data: {', '.join(hits)}")
    urls = re.findall(r"(?:https?://|www\.)[^\s]+", text, flags=re.I)
    for url in urls:
        u = url.lower()
        host = u.split("//", 1)[-1].split("/", 1)[0]
        if u.startswith("http://"):
            risk += 10
            flags.append(f"Unencrypted link (http): {url}")
        if re.match(r"\d{1,3}(\.\d{1,3}){3}(:\d+)?$", host):
            risk += 25
            flags.append(f"Link uses a raw IP address: {url}")
        if any(s in u for s in SHORTENERS):
            risk += 15
            flags.append(f"Shortened link hides destination: {url}")
        if "@" in host:
            risk += 20
            flags.append(f"'@' inside the domain part: {url}")
        bare = host.split(":")[0]
        if bare.endswith(BAD_TLDS):
            risk += 15
            flags.append(f"Suspicious top-level domain: {url}")
        if re.search(r"(paypa1|g00gle|arnazon|micros0ft|faceb00k|netfl1x|app1e)", bare):
            risk += 30
            flags.append(f"Look-alike brand spelling: {url}")
        if bare.count("-") >= 3 or bare.count(".") >= 4:
            risk += 10
            flags.append(f"Unusually complex domain: {url}")
    if re.search(r"(?i)dear (customer|user|member|valued)", text):
        risk += 10
        flags.append("Generic greeting instead of your name")
    if re.search(r"(?i)\b(gift card|lottery|you have won|claim your prize|inheritance)\b", text):
        risk += 20
        flags.append("Too-good-to-be-true offer")
    risk = min(100, risk)
    level = "Low" if risk < 25 else "Medium" if risk < 55 else "High"
    if not flags:
        flags.append("No obvious red flags - still verify the sender through an official channel.")
    return risk, level, flags
