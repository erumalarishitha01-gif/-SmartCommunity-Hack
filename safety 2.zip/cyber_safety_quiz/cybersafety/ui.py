"""Menu-driven terminal interface."""
from __future__ import annotations

import getpass
import json
import time

from . import __version__
from .engine import grade, password_strength, phishing_scan, select_questions, shuffle_options
from .export import export_chart, export_csv, export_markdown, export_text
from .importer import import_csv
from .models import ALL_CATEGORIES, NAME_RE, build_result
from .search import search
from .storage import SAMPLE_JSON, load_questions, load_results, next_id, save_results
from .summary import compute_summary, render_summary, results_table
from .validation import ask_choice, ask_int, ask_optional_int, ask_str, ask_yes_no

C = {"r": "\033[91m", "g": "\033[92m", "y": "\033[93m", "b": "\033[94m", "c": "\033[96m", "bold": "\033[1m", "0": "\033[0m"}
PAGE = 10


def paint(text, colour):
    return f"{C[colour]}{text}{C['0']}"


BANNER = r"""
   ____      _                ____        __      _
  / ___|   _| |__   ___ _ __ / ___|  __ _/ _| ___| |_ _   _
 | |  | | | | '_ \ / _ \ '__\\___ \ / _` | |_ / _ \ __| | | |
 | |__| |_| | |_) |  __/ |   ___) | (_| |  _|  __/ |_| |_| |
  \____\__, |_.__/ \___|_|  |____/ \__,_|_|  \___|\__|\__, |
       |___/        Q U I Z   -   think before you click |___/
"""


def welcome():
    print(paint(BANNER, "c"))
    print(paint(f"  Cyber Safety Quiz v{__version__} | SmartCommunity Hack | Passwords - Phishing - Online Safety\n", "b"))


MENU = """
  [1] Take a quiz              [6] Export report (MD/TXT/CSV)
  [2] Password strength check  [7] Import CSV dataset
  [3] Phishing message scan    [8] Load sample data
  [4] View / search records    [9] Chart (needs matplotlib)
  [5] Summary report           [0] Exit
"""

LEVEL_COLOUR = {"Cyber Pro": "g", "Aware": "y", "At Risk": "r"}


def take_quiz(results):
    questions = load_questions()
    name = ask_str("Your name: ", pattern=NAME_RE.pattern, max_len=30,
                   error="Use letters, digits, space, . _ ' - (max 30).")
    print("Categories: 1) password  2) phishing  3) online_safety  4) mixed")
    category = ALL_CATEGORIES[ask_int("Choose category (1-4): ", 1, 4) - 1]
    available = len([q for q in questions if category == "mixed" or q["category"] == category])
    if available == 0:
        print(paint("No questions available for that category.", "r"))
        return
    count = ask_int(f"How many questions (1-{min(10, available)})? ", 1, min(10, available))
    picked = [shuffle_options(q) for q in select_questions(questions, category, count)]
    flags, start = [], time.monotonic()
    for i, q in enumerate(picked, 1):
        print(f"\n{paint(f'Q{i}/{len(picked)}', 'bold')} [{q['category']}] {q['question']}")
        for n, opt in enumerate(q["options"], 1):
            print(f"   {n}) {opt}")
        choice = ask_int(f"Answer (1-{len(q['options'])}): ", 1, len(q["options"])) - 1
        ok = choice == q["answer"]
        flags.append(ok)
        print(paint("  Correct!", "g") if ok else paint(f"  Wrong - answer: {q['options'][q['answer']]}", "r"))
        print(f"  Tip: {q['explanation']}")
    duration = time.monotonic() - start
    res = build_result(next_id(results), name, category, len(picked), grade(flags), duration)
    results.append(res.to_dict())
    save_results(results)
    print(f"\nScore: {res.correct}/{res.total} ({res.percent}%)  Level: " + paint(res.level, LEVEL_COLOUR[res.level]))
    print("Result saved.")
    if res.percent < 40:
        print(paint("  [!] WARNING: score below 40% - review the tips above and retry this category.", "y"))
    elif res.duration_sec < 0.5 * res.total:
        print(paint("  [!] WARNING: answers were unusually fast - this attempt is flagged as anomalous.", "y"))


def password_check():
    print("(Input is hidden and never stored.)")
    try:
        pw = getpass.getpass("Password to test: ")
    except (EOFError, KeyboardInterrupt):
        return
    except Exception:  # no TTY (e.g. piped input): fall back to normal prompt
        pw = input("Password to test: ")
    score, label, notes = password_strength(pw)
    colour = "r" if score < 40 else "y" if score < 70 else "g"
    print(f"Strength: {paint(f'{label} ({score}/100)', colour)}")
    for n in notes:
        print(f"  - {n}")


def phishing_check():
    text = ask_str("Paste a message or URL to scan: ", max_len=2000)
    risk, level, flags = phishing_scan(text)
    colour = {"Low": "g", "Medium": "y", "High": "r"}[level]
    print(f"Phishing risk: {paint(f'{level} ({risk}/100)', colour)}")
    for f in flags:
        print(f"  [!] {f}")


def paginate(rows):
    if not rows:
        print("No matching records.")
        return
    page, pages = 0, (len(rows) - 1) // PAGE + 1
    while True:
        print(results_table(rows[page * PAGE:(page + 1) * PAGE]))
        print(f"Page {page + 1}/{pages} - {len(rows)} record(s)")
        if pages == 1:
            return
        cmd = ask_choice("[n]ext, [p]revious, [q]uit: ", ["n", "p", "q"])
        if cmd == "q":
            return
        page = min(page + 1, pages - 1) if cmd == "n" else max(page - 1, 0)


def view_records(results):
    print("  1) All  2) Keyword  3) Category  4) Level  5) Score range")
    opt = ask_int("Choose (1-5): ", 1, 5)
    if opt == 1:
        rows = results
    elif opt == 2:
        rows = search(results, keyword=ask_str("Keyword: ", max_len=40))
    elif opt == 3:
        rows = search(results, category=ask_choice("Category (password/phishing/online_safety/mixed): ", ALL_CATEGORIES))
    elif opt == 4:
        rows = search(results, level=ask_choice("Level (cyber pro/aware/at risk): ", ["cyber pro", "aware", "at risk"]))
    else:
        lo = ask_optional_int("Min % (blank = 0): ", 0, 100)
        hi = ask_optional_int("Max % (blank = 100): ", 0, 100)
        rows = search(results, min_pct=lo, max_pct=hi)
    paginate(sorted(rows, key=lambda r: r["id"]))


def summary(results):
    s = compute_summary(results)
    text = render_summary(s)
    print(text.replace("[!]", paint("[!]", "y")))


def export_menu(results):
    if not results:
        print("Nothing to export yet.")
        return
    for fn in (export_markdown, export_text, export_csv):
        print("  wrote", fn(results))


def import_menu(results):
    path = ask_str("Path to CSV (columns: name,category,total,correct,duration_sec[,timestamp]): ")
    count, errors, log = import_csv(path, results)
    if count:
        save_results(results)
    print(f"Imported {count} row(s); {len(errors)} error(s).")
    for e in errors[:10]:
        print(paint("  ! " + e, "r"))
    if log:
        print(f"Full error log: {log}")


def load_sample(results):
    try:
        with open(SAMPLE_JSON, encoding="utf-8") as fh:
            sample = json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        print(paint("Sample file missing; run tools/generate_sample_data.py", "r"))
        return
    existing = {(r["timestamp"], r["name"], r["category"]) for r in results}
    added = 0
    for row in sample:
        key = (row["timestamp"], row["name"], row["category"])
        if key in existing:
            continue
        try:
            results.append(build_result(next_id(results), row["name"], row["category"], row["total"],
                                        row["correct"], row["duration_sec"], row["timestamp"]).to_dict())
            added += 1
        except ValueError:
            continue
    save_results(results)
    print(f"Loaded {added} sample record(s).")


def chart(results):
    path = export_chart(results)
    print(f"Chart saved: {path}" if path else "Chart unavailable (install matplotlib or add records).")


def startup_alert(results):
    s = compute_summary(results)
    if s["count"] and s["warnings"]:
        print(paint(f"  [!] {len(s['warnings'])} warning(s) in saved data - see Summary report [5].", "y"))


def run():
    results = load_results()
    welcome()
    startup_alert(results)
    actions = {
        "1": lambda: take_quiz(results), "2": password_check, "3": phishing_check,
        "4": lambda: view_records(results), "5": lambda: summary(results),
        "6": lambda: export_menu(results), "7": lambda: import_menu(results),
        "8": lambda: load_sample(results), "9": lambda: chart(results),
    }
    while True:
        print(MENU)
        choice = ask_choice("Select an option: ", list(actions) + ["0"])
        if choice == "0":
            save_results(results)
            print("Stay safe online! Goodbye.")
            return
        try:
            actions[choice]()
        except ValueError as exc:
            print(paint(f"Could not complete action: {exc}", "r"))
