"""Data structures and record validation."""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from datetime import datetime

CATEGORIES = ("password", "phishing", "online_safety")
ALL_CATEGORIES = CATEGORIES + ("mixed",)
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.'-]{0,29}$")
MAX_QUESTIONS = 50


@dataclass
class Question:
    id: int
    category: str
    question: str
    options: list
    answer: int
    explanation: str


@dataclass
class Result:
    id: int
    timestamp: str
    name: str
    category: str
    total: int
    correct: int
    percent: float
    level: str
    duration_sec: float

    def to_dict(self) -> dict:
        return asdict(self)


def classify(percent: float) -> str:
    """Map a score to an awareness level."""
    if percent >= 80:
        return "Cyber Pro"
    if percent >= 50:
        return "Aware"
    return "At Risk"


def build_result(rid, name, category, total, correct, duration_sec, timestamp=None) -> Result:
    """Validate raw values and return a Result. Raises ValueError listing every problem."""
    errors = []
    name = str(name).strip()
    if not NAME_RE.match(name):
        errors.append("name must be 1-30 chars (letters, digits, space, . _ ' -)")
    category = str(category).strip().lower()
    if category not in ALL_CATEGORIES:
        errors.append(f"category must be one of {', '.join(ALL_CATEGORIES)}")
    try:
        total = int(total)
        if not 1 <= total <= MAX_QUESTIONS:
            errors.append(f"total must be 1-{MAX_QUESTIONS}")
    except (TypeError, ValueError):
        errors.append("total must be an integer")
        total = None
    try:
        correct = int(correct)
        if correct < 0 or (total is not None and correct > total):
            errors.append("correct must be between 0 and total")
    except (TypeError, ValueError):
        errors.append("correct must be an integer")
        correct = None
    try:
        duration_sec = float(duration_sec)
        if duration_sec < 0 or duration_sec > 86400:
            errors.append("duration_sec must be between 0 and 86400")
    except (TypeError, ValueError):
        errors.append("duration_sec must be a number")
        duration_sec = None
    if timestamp in (None, ""):
        timestamp = datetime.now().isoformat(timespec="seconds")
    else:
        try:
            timestamp = datetime.fromisoformat(str(timestamp).strip()).isoformat(timespec="seconds")
        except ValueError:
            errors.append("timestamp must be ISO format (YYYY-MM-DDTHH:MM:SS)")
    if errors:
        raise ValueError("; ".join(errors))
    percent = round(correct / total * 100, 1)
    return Result(int(rid), timestamp, name, category, total, correct, percent,
                  classify(percent), round(duration_sec, 1))
