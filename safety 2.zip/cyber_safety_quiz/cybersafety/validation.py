"""Centralised, crash-proof input helpers (loop until valid)."""
from __future__ import annotations

import re


def _read(prompt: str) -> str:
    try:
        return input(prompt)
    except (EOFError, KeyboardInterrupt):
        print("\nInput closed - exiting safely.")
        raise SystemExit(0)


def ask_str(prompt, pattern=None, min_len=1, max_len=200, error="Invalid input.") -> str:
    while True:
        value = _read(prompt).strip()
        if not (min_len <= len(value) <= max_len):
            print(f"  ! Enter {min_len}-{max_len} characters.")
            continue
        if pattern and not re.match(pattern, value):
            print(f"  ! {error}")
            continue
        return value


def ask_int(prompt, lo, hi) -> int:
    while True:
        raw = _read(prompt).strip()
        try:
            value = int(raw)
        except ValueError:
            print("  ! Please enter a whole number.")
            continue
        if not lo <= value <= hi:
            print(f"  ! Number must be between {lo} and {hi}.")
            continue
        return value


def ask_optional_int(prompt, lo, hi):
    """Blank input returns None."""
    while True:
        raw = _read(prompt).strip()
        if raw == "":
            return None
        try:
            value = int(raw)
        except ValueError:
            print("  ! Please enter a whole number or leave blank.")
            continue
        if lo <= value <= hi:
            return value
        print(f"  ! Number must be between {lo} and {hi}.")


def ask_choice(prompt, choices) -> str:
    choices = [c.lower() for c in choices]
    while True:
        value = _read(prompt).strip().lower()
        if value in choices:
            return value
        print(f"  ! Choose one of: {', '.join(choices)}")


def ask_yes_no(prompt) -> bool:
    return ask_choice(prompt + " (y/n): ", ["y", "n"]) == "y"
