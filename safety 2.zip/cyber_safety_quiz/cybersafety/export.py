"""Markdown / text / CSV exports and optional chart."""
from __future__ import annotations

import csv
from datetime import datetime

from .storage import EXPORT_DIR
from .summary import compute_summary, render_summary, results_table

FIELDS = ["id", "timestamp", "name", "category", "total", "correct", "percent", "level", "duration_sec"]


def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_markdown(results, out_dir=EXPORT_DIR):
    out_dir.mkdir(parents=True, exist_ok=True)
    s = compute_summary(results)
    path = out_dir / f"report_{_stamp()}.md"
    md = ["# Cyber Safety Quiz Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if s["count"]:
        md += [f"- **Attempts:** {s['count']}", f"- **Average:** {s['average_pct']}%", f"- **Trend:** {s['trend']}",
               f"- **Weakest category:** {s['weakest_category']}", "", "## By category", "",
               "| Category | Attempts | Avg |", "|---|---|---|"]
        md += [f"| {c} | {v['attempts']} | {v['avg']}% |" for c, v in s["by_category"].items()]
        md += ["", "## Warnings", ""] + ([f"- {w}" for w in s["warnings"]] or ["- None"])
        md += ["", "## Records", "", "| ID | Name | Category | Score | Level |", "|---|---|---|---|---|"]
        md += [f"| {r['id']} | {r['name']} | {r['category']} | {r['correct']}/{r['total']} ({r['percent']}%) | {r['level']} |" for r in results]
    else:
        md.append("No records.")
    path.write_text("\n".join(md) + "\n", encoding="utf-8")
    return path


def export_text(results, out_dir=EXPORT_DIR):
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"audit_{_stamp()}.txt"
    path.write_text(render_summary(compute_summary(results)) + "\n\n" + results_table(results) + "\n", encoding="utf-8")
    return path


def export_csv(results, out_dir=EXPORT_DIR):
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"results_{_stamp()}.csv"
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(results)
    return path


def export_chart(results, out_dir=EXPORT_DIR):
    """PNG dashboard: average score by category + score trend (needs matplotlib)."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = compute_summary(results)
    if not s["count"]:
        return None
    out_dir.mkdir(parents=True, exist_ok=True)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    cats = list(s["by_category"])
    vals = [s["by_category"][c]["avg"] for c in cats]
    bars = a1.bar(cats, vals, color=["#2a7de1", "#e1822a", "#2ab27b", "#8a5cd6"][:len(cats)])
    a1.bar_label(bars, fmt="%.1f%%")
    a1.set_ylim(0, 100)
    a1.set_ylabel("Average score (%)")
    a1.set_title("Average score by category")
    ordered = sorted(results, key=lambda r: r["timestamp"])
    pcts = [r["percent"] for r in ordered]
    a2.plot(range(1, len(pcts) + 1), pcts, marker="o", markersize=3, color="#2a7de1", linewidth=1)
    a2.axhline(40, color="#d64545", linestyle="--", linewidth=1, label="At Risk threshold (40%)")
    a2.set_ylim(0, 105)
    a2.set_xlabel("Attempt (chronological)")
    a2.set_ylabel("Score (%)")
    a2.set_title(f"Score trend - {s['trend']}")
    a2.legend(loc="lower right", fontsize=8)
    fig.suptitle("Cyber Safety Quiz - dashboard", fontweight="bold")
    fig.tight_layout()
    path = out_dir / f"chart_{_stamp()}.png"
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path
