"""Aggregation, warning flags and text rendering of the executive summary."""
from __future__ import annotations

from collections import Counter, defaultdict

LOW_SCORE = 40.0
AVG_WARN = 50.0


def compute_summary(results: list) -> dict:
    if not results:
        return {"count": 0}
    n = len(results)
    avg = sum(r["percent"] for r in results) / n
    by_cat = defaultdict(list)
    for r in results:
        by_cat[r["category"]].append(r["percent"])
    ordered = sorted(results, key=lambda r: r["timestamp"])
    trend = "Not enough data"
    if n >= 4:
        half = n // 2
        a = sum(r["percent"] for r in ordered[:half]) / half
        b = sum(r["percent"] for r in ordered[half:]) / (n - half)
        trend = "Improving" if b - a > 3 else "Declining" if a - b > 3 else "Stable"
    warnings = []
    low = [r for r in results if r["percent"] < LOW_SCORE]
    if low:
        warnings.append(f"{len(low)} attempt(s) scored below {LOW_SCORE:.0f}% (At Risk).")
    if avg < AVG_WARN:
        warnings.append(f"Overall average is below {AVG_WARN:.0f}% - awareness training recommended.")
    fast = [r for r in results if r["duration_sec"] < 0.5 * r["total"]]
    if fast:
        warnings.append(f"{len(fast)} anomalous attempt(s): answered faster than 0.5s per question.")
    weakest = min(by_cat.items(), key=lambda kv: sum(kv[1]) / len(kv[1]))
    return {
        "count": n,
        "participants": len({r["name"].lower() for r in results}),
        "total_questions": sum(r["total"] for r in results),
        "total_correct": sum(r["correct"] for r in results),
        "average_pct": round(avg, 1),
        "best": max(results, key=lambda r: r["percent"]),
        "worst": min(results, key=lambda r: r["percent"]),
        "avg_duration": round(sum(r["duration_sec"] for r in results) / n, 1),
        "by_category": {c: {"attempts": len(v), "avg": round(sum(v) / len(v), 1)} for c, v in sorted(by_cat.items())},
        "levels": dict(Counter(r["level"] for r in results)),
        "trend": trend,
        "weakest_category": weakest[0],
        "warnings": warnings,
    }


def table(rows: list, headers: list) -> str:
    """Fixed-width text table."""
    widths = [max([len(str(h))] + [len(str(r[i])) for r in rows]) for i, h in enumerate(headers)]
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt(cells):
        return "| " + " | ".join(str(c).ljust(w) for c, w in zip(cells, widths)) + " |"

    return "\n".join([line, fmt(headers), line, *(fmt(r) for r in rows), line])


def results_table(results: list) -> str:
    rows = [(r["id"], r["timestamp"].replace("T", " "), r["name"][:20], r["category"],
             f'{r["correct"]}/{r["total"]}', f'{r["percent"]}%', r["level"], f'{r["duration_sec"]}s') for r in results]
    return table(rows, ["ID", "When", "Name", "Category", "Score", "Pct", "Level", "Time"])


def render_summary(s: dict) -> str:
    if not s["count"]:
        return "No records yet - take a quiz or load sample data."
    lines = [
        "EXECUTIVE SUMMARY", "=" * 17,
        f"Attempts: {s['count']}   Participants: {s['participants']}   Questions answered: {s['total_questions']}",
        f"Total correct: {s['total_correct']}   Average score: {s['average_pct']}%   Avg time: {s['avg_duration']}s",
        f"Best:  {s['best']['name']} ({s['best']['percent']}%, {s['best']['category']})",
        f"Worst: {s['worst']['name']} ({s['worst']['percent']}%, {s['worst']['category']})",
        f"Trend: {s['trend']}   Weakest category: {s['weakest_category']}", "",
        "By category:",
        table([(c, v["attempts"], f"{v['avg']}%") for c, v in s["by_category"].items()], ["Category", "Attempts", "Avg"]),
        "", "Level distribution:",
        table([(k, v) for k, v in sorted(s["levels"].items())], ["Level", "Count"]), "",
    ]
    lines.append("Warnings:" if s["warnings"] else "No warnings - all indicators healthy.")
    lines += [f"  [!] {w}" for w in s["warnings"]]
    return "\n".join(lines)
