"""Cyber Safety Quiz - password, phishing and online-safety awareness trainer."""
__version__ = "1.1.0"
