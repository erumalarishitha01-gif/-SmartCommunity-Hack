"""Optional Tkinter GUI (stretch feature).  Launch with:  python main.py --gui"""
from __future__ import annotations

import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import __version__
from .engine import grade, password_strength, phishing_scan, select_questions, shuffle_options
from .export import export_chart, export_csv, export_markdown, export_text
from .importer import import_csv
from .models import ALL_CATEGORIES, NAME_RE, build_result
from .search import search
from .storage import load_questions, load_results, next_id, save_results
from .summary import compute_summary, render_summary

LEVEL_FG = {"Cyber Pro": "#1a8a3c", "Aware": "#b07800", "At Risk": "#c0392b"}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Cyber Safety Quiz v{__version__}")
        self.geometry("900x620")
        self.minsize(780, 540)
        self.results = load_results()
        self.questions = load_questions()
        self.quiz = None
        tk.Label(self, text="Cyber Safety Quiz", font=("Segoe UI", 20, "bold"), fg="#1f5fbf").pack(pady=(10, 0))
        tk.Label(self, text="Passwords - Phishing - Online Safety", fg="#555").pack()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=10)
        self._quiz_tab()
        self._password_tab()
        self._phishing_tab()
        self._records_tab()
        self._summary_tab()
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self._refresh())
        self.protocol("WM_DELETE_WINDOW", self._close)

    # ---- helpers
    def _close(self):
        save_results(self.results)
        self.destroy()

    def _refresh(self):
        self._fill_records(self.results)
        self._fill_summary()

    # ---- quiz tab
    def _quiz_tab(self):
        f = ttk.Frame(self.nb, padding=12)
        self.nb.add(f, text="Take Quiz")
        self.q_setup = ttk.Frame(f)
        self.q_setup.pack(fill="x")
        ttk.Label(self.q_setup, text="Name:").grid(row=0, column=0, sticky="w", pady=4)
        self.name_var = tk.StringVar()
        ttk.Entry(self.q_setup, textvariable=self.name_var, width=30).grid(row=0, column=1, sticky="w")
        ttk.Label(self.q_setup, text="Category:").grid(row=1, column=0, sticky="w", pady=4)
        self.cat_var = tk.StringVar(value="mixed")
        ttk.Combobox(self.q_setup, textvariable=self.cat_var, values=list(ALL_CATEGORIES), state="readonly",
                     width=27).grid(row=1, column=1, sticky="w")
        ttk.Label(self.q_setup, text="Questions:").grid(row=2, column=0, sticky="w", pady=4)
        self.count_var = tk.IntVar(value=5)
        ttk.Spinbox(self.q_setup, from_=1, to=10, textvariable=self.count_var, width=5).grid(row=2, column=1, sticky="w")
        ttk.Button(self.q_setup, text="Start quiz", command=self._start_quiz).grid(row=3, column=1, sticky="w", pady=8)
        self.q_box = ttk.Frame(f)
        self.q_label = ttk.Label(self.q_box, wraplength=780, font=("Segoe UI", 12, "bold"))
        self.q_label.pack(anchor="w", pady=6)
        self.choice = tk.IntVar(value=-1)
        self.radios = []
        for i in range(4):
            r = ttk.Radiobutton(self.q_box, variable=self.choice, value=i)
            r.pack(anchor="w", pady=2)
            self.radios.append(r)
        self.feedback = ttk.Label(self.q_box, wraplength=780)
        self.feedback.pack(anchor="w", pady=8)
        self.q_btn = ttk.Button(self.q_box, text="Submit", command=self._submit)
        self.q_btn.pack(anchor="w")
        self.result_label = ttk.Label(f, font=("Segoe UI", 12, "bold"), wraplength=780)
        self.result_label.pack(anchor="w", pady=10)

    def _start_quiz(self):
        name = self.name_var.get().strip()
        if not NAME_RE.match(name):
            messagebox.showerror("Invalid name", "Name must be 1-30 characters (letters, digits, space, . _ ' -).")
            return
        try:
            count = int(self.count_var.get())
        except (tk.TclError, ValueError):
            messagebox.showerror("Invalid number", "Questions must be a whole number from 1 to 10.")
            return
        if not 1 <= count <= 10:
            messagebox.showerror("Invalid number", "Questions must be between 1 and 10.")
            return
        picked = [shuffle_options(q) for q in select_questions(self.questions, self.cat_var.get(), count)]
        if not picked:
            messagebox.showerror("No questions", "No questions available for that category.")
            return
        self.quiz = {"qs": picked, "i": 0, "flags": [], "start": time.monotonic(), "answered": False}
        self.q_setup.pack_forget()
        self.result_label.config(text="")
        self.q_box.pack(fill="x")
        self._show_question()

    def _show_question(self):
        qz = self.quiz
        q = qz["qs"][qz["i"]]
        self.q_label.config(text=f"Q{qz['i'] + 1}/{len(qz['qs'])}: {q['question']}")
        self.choice.set(-1)
        for i, r in enumerate(self.radios):
            if i < len(q["options"]):
                r.config(text=q["options"][i], state="normal")
                r.pack(anchor="w", pady=2)
            else:
                r.pack_forget()
        self.feedback.config(text="", foreground="black")
        qz["answered"] = False
        self.q_btn.config(text="Submit")

    def _submit(self):
        qz = self.quiz
        if qz["answered"]:
            qz["i"] += 1
            if qz["i"] >= len(qz["qs"]):
                return self._finish()
            return self._show_question()
        pick = self.choice.get()
        if pick < 0:
            messagebox.showwarning("Choose an answer", "Please select one of the options.")
            return
        q = qz["qs"][qz["i"]]
        ok = pick == q["answer"]
        qz["flags"].append(ok)
        qz["answered"] = True
        msg = "Correct! " if ok else f"Wrong - answer: {q['options'][q['answer']]}. "
        self.feedback.config(text=msg + q["explanation"], foreground="#1a8a3c" if ok else "#c0392b")
        last = qz["i"] + 1 >= len(qz["qs"])
        self.q_btn.config(text="Finish" if last else "Next")

    def _finish(self):
        qz = self.quiz
        res = build_result(next_id(self.results), self.name_var.get(), self.cat_var.get(), len(qz["qs"]),
                           grade(qz["flags"]), time.monotonic() - qz["start"])
        self.results.append(res.to_dict())
        save_results(self.results)
        self.q_box.pack_forget()
        self.q_setup.pack(fill="x")
        txt = f"Score: {res.correct}/{res.total} ({res.percent}%) - {res.level}. Result saved."
        if res.percent < 40:
            txt += "\nWARNING: score below 40% - review the tips and retry."
        self.result_label.config(text=txt, foreground=LEVEL_FG[res.level])
        self.quiz = None

    # ---- password tab
    def _password_tab(self):
        f = ttk.Frame(self.nb, padding=12)
        self.nb.add(f, text="Password Check")
        ttk.Label(f, text="Type a password to test (never stored):").pack(anchor="w")
        self.pw_var = tk.StringVar()
        e = ttk.Entry(f, textvariable=self.pw_var, show="*", width=40)
        e.pack(anchor="w", pady=4)
        self.show_pw = tk.BooleanVar()
        ttk.Checkbutton(f, text="Show", variable=self.show_pw,
                        command=lambda: e.config(show="" if self.show_pw.get() else "*")).pack(anchor="w")
        self.pw_bar = ttk.Progressbar(f, maximum=100, length=300)
        self.pw_bar.pack(anchor="w", pady=6)
        self.pw_label = ttk.Label(f, font=("Segoe UI", 12, "bold"))
        self.pw_label.pack(anchor="w")
        self.pw_notes = ttk.Label(f, wraplength=780, justify="left")
        self.pw_notes.pack(anchor="w", pady=6)
        self.pw_var.trace_add("write", lambda *a: self._pw_update())

    def _pw_update(self):
        score, label, notes = password_strength(self.pw_var.get())
        self.pw_bar["value"] = score
        self.pw_label.config(text=f"{label} ({score}/100)")
        self.pw_notes.config(text="\n".join("- " + n for n in notes))

    # ---- phishing tab
    def _phishing_tab(self):
        f = ttk.Frame(self.nb, padding=12)
        self.nb.add(f, text="Phishing Scan")
        ttk.Label(f, text="Paste a message or URL:").pack(anchor="w")
        self.ph_text = tk.Text(f, height=8, wrap="word")
        self.ph_text.pack(fill="x", pady=4)
        ttk.Button(f, text="Scan", command=self._scan).pack(anchor="w")
        self.ph_label = ttk.Label(f, font=("Segoe UI", 12, "bold"))
        self.ph_label.pack(anchor="w", pady=6)
        self.ph_flags = ttk.Label(f, wraplength=780, justify="left")
        self.ph_flags.pack(anchor="w")

    def _scan(self):
        text = self.ph_text.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("Empty", "Paste some text to scan.")
            return
        risk, level, flags = phishing_scan(text[:2000])
        col = {"Low": "#1a8a3c", "Medium": "#b07800", "High": "#c0392b"}[level]
        self.ph_label.config(text=f"Phishing risk: {level} ({risk}/100)", foreground=col)
        self.ph_flags.config(text="\n".join("[!] " + f for f in flags))

    # ---- records tab
    def _records_tab(self):
        f = ttk.Frame(self.nb, padding=12)
        self.nb.add(f, text="Records")
        bar = ttk.Frame(f)
        bar.pack(fill="x")
        ttk.Label(bar, text="Keyword:").pack(side="left")
        self.kw_var = tk.StringVar()
        ttk.Entry(bar, textvariable=self.kw_var, width=18).pack(side="left", padx=4)
        ttk.Label(bar, text="Category:").pack(side="left")
        self.rc_var = tk.StringVar(value="all")
        ttk.Combobox(bar, textvariable=self.rc_var, values=["all", *ALL_CATEGORIES], state="readonly",
                     width=14).pack(side="left", padx=4)
        ttk.Button(bar, text="Search", command=lambda: self._fill_records(self.results)).pack(side="left", padx=4)
        ttk.Button(bar, text="Import CSV...", command=self._import).pack(side="right")
        cols = ("id", "when", "name", "category", "score", "pct", "level", "time")
        self.tree = ttk.Treeview(f, columns=cols, show="headings", height=16)
        for c, w in zip(cols, (40, 140, 130, 100, 60, 60, 90, 60)):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=w, anchor="w")
        sb = ttk.Scrollbar(f, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True, pady=8)
        sb.pack(side="right", fill="y", pady=8)

    def _fill_records(self, results):
        cat = self.rc_var.get()
        rows = search(results, keyword=self.kw_var.get().strip() or None, category=None if cat == "all" else cat)
        self.tree.delete(*self.tree.get_children())
        for r in sorted(rows, key=lambda r: r["id"]):
            self.tree.insert("", "end", values=(r["id"], r["timestamp"].replace("T", " "), r["name"], r["category"],
                                               f'{r["correct"]}/{r["total"]}', f'{r["percent"]}%', r["level"],
                                               f'{r["duration_sec"]}s'))

    def _import(self):
        path = filedialog.askopenfilename(title="Choose CSV", filetypes=[("CSV files", "*.csv"), ("All", "*.*")])
        if not path:
            return
        count, errors, log = import_csv(path, self.results)
        if count:
            save_results(self.results)
        msg = f"Imported {count} row(s); {len(errors)} error(s)."
        if errors:
            msg += "\n\n" + "\n".join(errors[:8]) + (f"\n\nFull log: {log}" if log else "")
        messagebox.showinfo("Import finished", msg)
        self._fill_records(self.results)

    # ---- summary tab
    def _summary_tab(self):
        f = ttk.Frame(self.nb, padding=12)
        self.nb.add(f, text="Summary")
        bar = ttk.Frame(f)
        bar.pack(fill="x")
        ttk.Button(bar, text="Export MD/TXT/CSV", command=self._export).pack(side="left")
        ttk.Button(bar, text="Save chart", command=self._chart).pack(side="left", padx=6)
        self.sum_text = tk.Text(f, font=("Consolas", 10), wrap="none", height=24)
        self.sum_text.pack(fill="both", expand=True, pady=8)

    def _fill_summary(self):
        self.sum_text.config(state="normal")
        self.sum_text.delete("1.0", "end")
        self.sum_text.insert("end", render_summary(compute_summary(self.results)))
        self.sum_text.config(state="disabled")

    def _export(self):
        if not self.results:
            messagebox.showinfo("Nothing to export", "No records yet.")
            return
        paths = [fn(self.results) for fn in (export_markdown, export_text, export_csv)]
        messagebox.showinfo("Exported", "\n".join(str(p) for p in paths))

    def _chart(self):
        p = export_chart(self.results)
        messagebox.showinfo("Chart", f"Saved: {p}" if p else "Chart unavailable (install matplotlib or add records).")


def run():
    App().mainloop()
