"""Bulk CSV import with row-by-row error log."""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from .models import build_result
from .storage import EXPORT_DIR, next_id

REQUIRED = {"name", "category", "total", "correct", "duration_sec"}


def import_csv(path, results: list):
    """Append valid rows to `results`. Returns (imported, errors list, error_log_path or None)."""
    path = Path(path).expanduser()
    errors, imported = [], 0
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            missing = REQUIRED - headers
            if missing:
                return 0, [f"Missing required column(s): {', '.join(sorted(missing))}"], None
            for line_no, row in enumerate(reader, start=2):
                row = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
                try:
                    res = build_result(next_id(results), row["name"], row["category"], row["total"],
                                       row["correct"], row["duration_sec"], row.get("timestamp"))
                    results.append(res.to_dict())
                    imported += 1
                except ValueError as exc:
                    errors.append(f"Row {line_no}: {exc}")
    except FileNotFoundError:
        return 0, [f"File not found: {path}"], None
    except (UnicodeDecodeError, csv.Error) as exc:
        return imported, [f"Unreadable CSV: {exc}"], None
    log = None
    if errors:
        EXPORT_DIR.mkdir(parents=True, exist_ok=True)
        log = EXPORT_DIR / f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log"
        log.write_text("\n".join(errors) + "\n", encoding="utf-8")
    return imported, errors, log
