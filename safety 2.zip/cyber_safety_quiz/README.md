# Cyber Safety Quiz (SmartCommunity Hack - Project #75)

A zero-dependency, menu-driven Python 3.10+ terminal app that tests password, phishing and
online-safety awareness, stores results locally and reports on them.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
python main.py          # terminal menu
python main.py --gui    # Tkinter window (needs Python with Tk)
```
Optional chart (menu 9): `pip install matplotlib`. Run tests: `python -m unittest discover -s tests`.

## Features
| Brief requirement | Where |
|---|---|
| Interactive terminal menu (ANSI colours, branded welcome) | `cybersafety/ui.py` |
| Defensive input validation (loops until valid; EOF/Ctrl-C safe) | `validation.py`, `models.build_result` |
| Core logic: quiz grading + levels, password-strength analyser, phishing red-flag scanner | `engine.py`, `models.py` |
| JSON persistence, atomic writes, corrupt/missing file recovery | `storage.py` |
| Search by keyword / category / level / score range, paginated tables | `search.py`, `ui.py` |
| Executive summary: totals, averages, by-category, trend, warnings | `summary.py` |
| Stretch: Markdown / TXT audit / CSV export, optional PNG chart | `export.py` |
| Stretch: threshold warnings (low scores, low average, too-fast answers) - also shown after a quiz and at startup | `summary.py`, `ui.py` |
| Stretch: Tkinter GUI (quiz, password, phishing, records, summary tabs) | `gui.py` |
| Stretch: bulk CSV import with row-by-row error log | `importer.py` |

## Data
* `data/questions.json` - 45 questions (15 per category, options shuffled each run). Add your own using the same fields.
* `data/sample_results.json|csv` - 45 seeded records incl. boundary cases (0%, 100%, 1 question, 50 questions, very fast/slow).
  Regenerate with `python tools/generate_sample_data.py`.
* `data/sample_bad_import.csv` - deliberately broken rows to demo the import error log.
* `data/results.json` is created on first run (your live records).

## 5-minute demo script
1. Launch `python main.py` -> branded welcome screen.
2. **[8]** load sample data, then **[1]** take a quiz; type `abc`, a blank name or `9` to show validation catching errors.
3. **[2]** test `123456` vs `correct-Horse-battery-9!`; **[3]** scan a suspicious message.
4. **[4]** search by keyword/category; **[5]** summary with trend + warnings.
5. Exit, relaunch, **[5]** again -> data persisted. **[6]** export reports (in `exports/`), **[7]** import `data/sample_bad_import.csv` to show the error log, **[9]** chart.

## Layout
```
main.py            entry point
cybersafety/       app package (models, validation, storage, engine, search, summary, export, importer, ui)
data/              question bank + sample datasets
tests/             unittest suite (10 tests)
tools/             sample-data generator, PDF report builder
docs/              Cyber_Safety_Quiz_Project_Report.pdf + sample dashboard
exports/           generated reports
```

## Ideas for next steps
Textual UI, timed mode, per-user history, difficulty levels, more questions.
