"""Build docs/Cyber_Safety_Quiz_Project_Report.pdf (needs reportlab)."""
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted, SimpleDocTemplate,
                                Spacer, Table, TableStyle)

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "Cyber_Safety_Quiz_Project_Report.pdf"
BLUE, GREY = colors.HexColor("#1f5fbf"), colors.HexColor("#555555")
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], textColor=BLUE, fontSize=16, spaceBefore=14, spaceAfter=6)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], textColor=BLUE, fontSize=12, spaceBefore=8, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=10, leading=14)
CELL = ParagraphStyle("C", parent=B, fontSize=8.5, leading=11)
CELLH = ParagraphStyle("CH", parent=CELL, textColor=colors.white, fontName="Helvetica-Bold")
CODE = ParagraphStyle("Code", fontName="Courier", fontSize=7.8, leading=9.6, backColor=colors.HexColor("#f4f6f8"),
                      borderPadding=6)


def p(t, s=B):
    return Paragraph(t, s)


def tbl(rows, widths, header=True):
    data = [[p(str(c), CELLH if (header and i == 0) else CELL) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c8ced6")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f6f8")])]
    if header:
        st.append(("BACKGROUND", (0, 0), (-1, 0), BLUE))
    t.setStyle(TableStyle(st))
    return t


def footer(c, d):
    c.saveState()
    c.setFont("Helvetica", 8)
    c.setFillColor(GREY)
    c.drawString(2 * cm, 1.2 * cm, "Cyber Safety Quiz - Project Report | SmartCommunity Hack, Project #75")
    c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {d.page}")
    c.restoreState()


s = []
s += [Spacer(1, 3 * cm), p("Cyber Safety Quiz", ParagraphStyle("T", parent=ss["Title"], textColor=BLUE, fontSize=30, leading=36, spaceAfter=8)),
      p("Project Report and Build Guide", ParagraphStyle("S", parent=ss["Title"], fontSize=16, leading=20, textColor=GREY)),
      Spacer(1, 0.6 * cm),
      p("SmartCommunity Hack | Project #75 | Domain: Safety &amp; Community", ParagraphStyle("c", parent=B, alignment=1)),
      p("Version 1.1.0 | Python 3.10+ | Standard library only (matplotlib and Tkinter optional)",
        ParagraphStyle("c2", parent=B, alignment=1, textColor=GREY)),
      Spacer(1, 1 * cm), Image(str(ROOT / "docs" / "sample_dashboard.png"), width=15.5 * cm, height=6.2 * cm),
      p("Figure: dashboard generated from the bundled 45-record sample dataset.",
        ParagraphStyle("cap", parent=B, alignment=1, fontSize=8, textColor=GREY)), PageBreak()]

s += [p("1. Overview", H1),
      p("Cyber Safety Quiz is a beginner-friendly Python application that tests and trains basic password, phishing and "
        "online-safety awareness. It runs entirely offline from a terminal menu (or an optional Tkinter window), validates "
        "every input, saves results to local JSON files so data survives restarts, and produces summaries, warnings, "
        "exports and charts. It uses only the Python standard library, so it runs on any laptop with no installs or "
        "licences."),
      p("2. Requirement traceability", H1),
      tbl([["Brief requirement", "Status", "Implementation"],
           ["Interactive terminal interface", "Done", "ui.py: ANSI-coloured, branded menu with 9 actions; startup warning banner"],
           ["Defensive input validation", "Done", "validation.py loops until valid; models.build_result checks every field; EOF/Ctrl-C safe"],
           ["Core logic engine", "Done", "engine.py: quiz selection, option shuffling, grading, levels; password-strength analyser; phishing red-flag scanner"],
           ["Local persistence (JSON/CSV)", "Done", "storage.py: atomic JSON writes, schema check, backup and reset on corrupt files"],
           ["Record query and search", "Done", "search.py: keyword, category, level and score-range filters; paginated fixed-width tables"],
           ["Executive summary", "Done", "summary.py: totals, averages, by-category, level distribution, trend, weakest category"],
           ["Multi-format export (stretch)", "Done", "export.py: Markdown report, TXT audit log, CSV, PNG dashboard"],
           ["Threshold warnings (stretch)", "Done", "Scores below 40%, average below 50%, anomalously fast answers; shown after a quiz and at startup"],
           ["Tkinter GUI (stretch)", "Done*", "gui.py, launched with <font face='Courier'>python main.py --gui</font>. *Needs a Python with Tk; not run in the build sandbox"],
           ["Bulk CSV import (stretch)", "Done", "importer.py: per-row validation and an error log file"],
           ["Matplotlib plotting", "Done", "Optional two-panel dashboard (category averages and score trend)"],
           ["30-50 sample entries", "Done", "45 records in CSV and JSON incl. 0%, 100%, 1-question, 50-question, very fast and very slow cases"]],
          [4.2 * cm, 1.6 * cm, 11.2 * cm]),
      p("3. Architecture", H1),
      p("The program is split into small modules so each hackathon teammate can own one piece. Data flows from the UI "
        "through validation into the engine and models, and is persisted by the storage layer."),
      Preformatted("""main.py                 entry point  (--gui for Tkinter)
cybersafety/
  ui.py                 terminal menu and dispatch loop
  gui.py                optional Tkinter front-end
  validation.py         ask_str / ask_int / ask_choice ... (loop until valid)
  models.py             Question, Result, build_result(), classify()
  engine.py             select + shuffle questions, grade, password_strength, phishing_scan
  storage.py            load/save JSON, corruption recovery, next_id
  search.py             keyword / category / level / score filters
  summary.py            compute_summary, tables, render_summary
  export.py             Markdown, TXT, CSV, PNG dashboard
  importer.py           CSV bulk import with error log
data/                   questions.json (45), sample_results.json|csv, sample_bad_import.csv
tests/test_app.py       10 unit tests
tools/                  generate_sample_data.py, build_report.py""", CODE), PageBreak()]

s += [p("4. Feature details", H1),
      p("4.1 Quiz and scoring", H2),
      p("The question bank holds 45 questions (15 each for password, phishing and online safety). A session asks 1-10 "
        "questions from one category or a mix. Answer options are shuffled every time so the correct answer is not in a "
        "fixed position. Each answer shows an explanation tip. Scores map to levels: <b>Cyber Pro</b> (80% and above), "
        "<b>Aware</b> (50-79%), <b>At Risk</b> (below 50%)."),
      p("4.2 Password-strength analyser", H2),
      p("Scores 0-100 from length (up to 20 characters) and character variety, then penalises common passwords, repeated "
        "characters and keyboard/sequential patterns, and returns actionable feedback. Example: <font face='Courier'>123456</font> "
        "scores 0 (Very Weak); <font face='Courier'>correct-Horse-battery-9!</font> scores 100 (Very Strong). Passwords are "
        "entered through a hidden prompt and are never stored."),
      p("4.3 Phishing scanner", H2),
      p("A rule-based scanner flags urgency language, requests for sensitive data, unencrypted or shortened links, raw-IP "
        "links, '@' tricks, suspicious top-level domains, look-alike brand spellings, generic greetings and "
        "too-good-to-be-true offers, then gives a Low/Medium/High risk level. It is an awareness aid, not a replacement for "
        "email security tools."),
      p("4.4 Persistence and fault tolerance", H2),
      p("Results are written atomically (temporary file then replace) to <font face='Courier'>data/results.json</font>. A missing "
        "file is created; a corrupted file is backed up and replaced with a clean template; rows that fail the schema "
        "check are skipped. Imported CSV rows are validated individually and failures are written to "
        "<font face='Courier'>exports/import_errors_*.log</font>."),
      p("4.5 Summary report (sample output)", H2),
      Preformatted(open("/tmp/summary.txt").read(), CODE), PageBreak()]

s += [p("5. How to run", H1),
      Preformatted("""python -m venv .venv
.venv\\Scripts\\activate          (Windows)   |   source .venv/bin/activate   (macOS/Linux)
python main.py                   terminal version
python main.py --gui             Tkinter version
pip install matplotlib           optional, enables the chart (menu 9 / Save chart)
python -m unittest discover -s tests""", CODE),
      p("6. Five-minute demo script", H1),
      tbl([["Step", "Action", "What it proves"],
           ["1", "Launch <font face='Courier'>python main.py</font>", "Branded welcome screen and clear menu"],
           ["2", "Option 8 (load sample data), then option 1: type abc, a blank name, then 9 at the answer prompt", "Defensive validation catches and corrects bad input"],
           ["3", "Option 2 with 123456 then a long passphrase; option 3 with a suspicious message", "Core logic engine"],
           ["4", "Option 4: search by keyword and category", "Record query and pagination"],
           ["5", "Option 5: summary", "Averages, trend and warning flags"],
           ["6", "Exit, relaunch, option 5 again", "Persistence across restarts"],
           ["7", "Option 6 (exports), option 7 with data/sample_bad_import.csv, option 9 (chart)", "Export, bulk import with error log, chart"]],
          [1.2 * cm, 9 * cm, 6.8 * cm]),
      p("7. Quality checks", H1),
      p("Ten automated unit tests cover validation rules, level boundaries, password and phishing logic, question-bank "
        "integrity, option shuffling, corrupt-file recovery, save/load round-trips, search, summary warnings, CSV import "
        "error handling and chart export. An end-to-end scripted terminal run (invalid inputs, quiz, search, exports, "
        "relaunch) confirmed that 47 records persisted after restart."),
      p("8. Known limitations and next steps", H1),
      tbl([["Limitation", "Idea for next iteration"],
           ["Tkinter GUI could not be executed in the build environment (Tk missing); the code compiles", "Run <font face='Courier'>python main.py --gui</font> on your laptop and report any layout issues"],
           ["Phishing scanner is heuristic and can give false positives or negatives", "Add more rules or a configurable rule file"],
           ["Single local JSON file, no per-user accounts", "Per-user history and a leaderboard"],
           ["45 questions", "Add difficulty levels, a timed mode and a community-contributed question pack"]],
          [8 * cm, 9 * cm])]

SimpleDocTemplate(str(OUT), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=2 * cm,
                  title="Cyber Safety Quiz - Project Report", author="SmartCommunity Hack Team").build(
    s, onFirstPage=lambda c, d: None, onLaterPages=footer)
print("wrote", OUT)
