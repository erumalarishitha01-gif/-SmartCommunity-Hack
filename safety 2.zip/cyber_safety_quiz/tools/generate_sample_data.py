"""Generate data/sample_results.csv and .json (45 records incl. boundary/edge cases)."""
import csv
import json
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from cybersafety.models import build_result  # noqa: E402

DATA = Path(__file__).resolve().parent.parent / "data"
rng = random.Random(75)
names = ["Aarav", "Diya", "Rohan", "Sneha", "Kabir", "Meera", "Ishaan", "Priya", "Vikram", "Anaya",
         "Arjun", "Nisha", "Rahul", "Tara", "Zoya"]
cats = ["password", "phishing", "online_safety", "mixed"]
base = datetime(2026, 9, 1, 9, 0, 0)
rows = []
for i in range(38):  # normal entries with a gentle improving trend
    cat = rng.choice(cats)
    total = rng.choice([5, 8, 10])
    skill = 0.45 + i * 0.01 + rng.uniform(-0.15, 0.2)
    correct = max(0, min(total, round(total * skill)))
    rows.append((names[i % len(names)], cat, total, correct, round(total * rng.uniform(6, 20), 1),
                 (base + timedelta(hours=i * 7)).isoformat(timespec="seconds")))
edge = [  # boundary values and edge conditions
    ("Edge Zero", "password", 10, 0, 45.0), ("Edge Perfect", "phishing", 10, 10, 60.0),
    ("Edge One", "online_safety", 1, 1, 4.2), ("Edge Max", "mixed", 50, 25, 600.0),
    ("Speedy", "mixed", 10, 10, 1.5), ("Slow Poke", "password", 5, 2, 3600.0),
    ("Half Way", "phishing", 8, 4, 70.0),
]
for j, (n, c, t, k, d) in enumerate(edge):
    rows.append((n, c, t, k, d, (base + timedelta(days=12, hours=j)).isoformat(timespec="seconds")))

records = [build_result(i + 1, *r[:5], timestamp=r[5]).to_dict() for i, r in enumerate(rows)]
(DATA / "sample_results.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
with open(DATA / "sample_results.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["name", "category", "total", "correct", "duration_sec", "timestamp"])
    for r in records:
        w.writerow([r["name"], r["category"], r["total"], r["correct"], r["duration_sec"], r["timestamp"]])
# deliberately messy file to demo import error logging
with open(DATA / "sample_bad_import.csv", "w", newline="", encoding="utf-8") as fh:
    fh.write("name,category,total,correct,duration_sec,timestamp\n"
             "Good Row,password,5,4,30,2026-10-01T10:00:00\n"
             "Bad Category,gaming,5,4,30,2026-10-01T10:05:00\n"
             "Too Many Correct,phishing,5,9,30,2026-10-01T10:10:00\n"
             ",password,5,3,30,\n"
             "Not A Number,password,five,3,30,\n"
             "Bad Date,mixed,5,3,30,yesterday\n"
             "Another Good,online_safety,10,7,88.5,2026-10-02T09:00:00\n")
print(f"Wrote {len(records)} sample records")
