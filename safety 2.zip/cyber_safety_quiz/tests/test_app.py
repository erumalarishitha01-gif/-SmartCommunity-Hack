import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from cybersafety.engine import password_strength, phishing_scan, select_questions, shuffle_options
from cybersafety.importer import import_csv
from cybersafety.models import build_result, classify
from cybersafety.search import search
from cybersafety.storage import load_questions, load_results, save_results
from cybersafety.summary import compute_summary

DATA = Path(__file__).resolve().parent.parent / "data"


class Tests(unittest.TestCase):
    def test_build_result_ok_and_levels(self):
        r = build_result(1, "Ann", "password", 10, 8, 30)
        self.assertEqual((r.percent, r.level), (80.0, "Cyber Pro"))
        self.assertEqual(classify(49.9), "At Risk")
        self.assertEqual(classify(50), "Aware")

    def test_build_result_rejects_bad_values(self):
        for args in [("", "password", 5, 1, 5), ("A", "x", 5, 1, 5), ("A", "mixed", 5, 6, 5),
                     ("A", "mixed", 0, 0, 5), ("A", "mixed", "z", 1, 5), ("A", "mixed", 5, 1, -1)]:
            with self.assertRaises(ValueError):
                build_result(1, *args)

    def test_password_strength(self):
        self.assertLess(password_strength("123456")[0], 15)
        self.assertGreaterEqual(password_strength("correct-Horse-battery-9!")[0], 80)

    def test_phishing(self):
        risk, level, _ = phishing_scan("URGENT: verify your account at http://paypa1-login.xyz now, enter password")
        self.assertEqual(level, "High")
        self.assertEqual(phishing_scan("Lunch at 1pm?")[1], "Low")

    def test_questions_and_selection(self):
        qs = load_questions()
        self.assertGreaterEqual(len(qs), 40)
        self.assertEqual(len(select_questions(qs, "phishing", 5)), 5)
        self.assertTrue(all(q["category"] == "phishing" for q in select_questions(qs, "phishing", 20)))

    def test_shuffle_keeps_correct_answer(self):
        for q in load_questions():
            s = shuffle_options(q)
            self.assertEqual(s["options"][s["answer"]], q["options"][q["answer"]])
            self.assertCountEqual(s["options"], q["options"])

    def test_chart_export(self):
        try:
            import matplotlib  # noqa: F401
        except ImportError:
            self.skipTest("matplotlib not installed")
        from cybersafety.export import export_chart
        with tempfile.TemporaryDirectory() as d:
            data = json.loads((DATA / "sample_results.json").read_text())
            p = export_chart(data, Path(d))
            self.assertTrue(p and p.stat().st_size > 5000)

    def test_storage_recovers_from_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "results.json"
            self.assertEqual(load_results(p), [])          # missing -> created
            p.write_text("{not json", encoding="utf-8")
            self.assertEqual(load_results(p), [])          # corrupt -> backup + reset
            self.assertTrue(list(Path(d).glob("*.corrupt-*")))
            p.write_text(json.dumps([{"id": 1}, 5]), encoding="utf-8")
            self.assertEqual(load_results(p), [])          # bad rows skipped

    def test_roundtrip_search_summary(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "r.json"
            data = json.loads((DATA / "sample_results.json").read_text())
            save_results(data, p)
            loaded = load_results(p)
            self.assertEqual(len(loaded), len(data))
            self.assertTrue(search(loaded, category="password"))
            s = compute_summary(loaded)
            self.assertEqual(s["count"], len(loaded))
            self.assertTrue(s["warnings"])

    def test_import_errors(self):
        results = []
        n, errs, log = import_csv(DATA / "sample_bad_import.csv", results)
        self.assertEqual(n, 2)
        self.assertEqual(len(errs), 5)
        self.assertTrue(log and log.exists())
        log.unlink()
        self.assertEqual(import_csv("nope.csv", [])[0], 0)


if __name__ == "__main__":
    unittest.main()
