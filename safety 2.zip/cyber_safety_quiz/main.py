"""Cyber Safety Quiz - entry point.

    python main.py          terminal menu (default)
    python main.py --gui    Tkinter window
"""
import sys


def main():
    if "--gui" in sys.argv[1:]:
        try:
            from cybersafety.gui import run as run_gui
        except ImportError:
            print("Tkinter is not available in this Python install - starting the terminal version instead.")
        else:
            return run_gui()
    from cybersafety.ui import run
    run()


if __name__ == "__main__":
    main()
